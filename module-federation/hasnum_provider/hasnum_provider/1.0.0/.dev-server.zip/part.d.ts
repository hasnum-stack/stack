export * from './compiled-types/components/Part/index';
export { default } from './compiled-types/components/Part/index';