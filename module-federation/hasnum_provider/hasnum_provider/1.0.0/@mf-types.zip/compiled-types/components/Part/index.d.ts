import React from 'react';
import './index.less';
declare const Provider: React.FC;
export default Provider;
