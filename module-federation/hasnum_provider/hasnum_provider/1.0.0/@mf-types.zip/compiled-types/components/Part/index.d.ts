import React from 'react';
import './index.less';
declare const Part: React.FC;
export default Part;
